##For a short introduction see:
\dontrun{
  vignette("ST_intro",package="SpatioTemporal")
}

##For a worked out data-analysis exmaple see the tutorial.
##NOTE: This vignette is still work in progress
\dontrun{
  vignette("Tutorial",package="SpatioTemporal")
}

